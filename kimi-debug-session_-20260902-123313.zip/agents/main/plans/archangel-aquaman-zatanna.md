# Al Noor Engineers — Static Website (React + Tailwind)

## Goal
Build a fully responsive 4-page static site (Home, About, Services, Contact) in `/home/shumail/um-pro`
implementing the design brief exactly: "a network operations room, rendered as a website."
Charcoal/off-white token system, rack-elevation row components, one amber accent tied to status
semantics, one orchestrated hero animation, real content from the brief — no lorem ipsum, no
generic SaaS card kit.

## Stack decision
- **Vite + React 18 + react-router-dom** (BrowserRouter, 4 routes). Node 24 / npm 11 confirmed.
- **Tailwind CSS v4** via `@tailwindcss/vite` plugin; design tokens defined in `src/index.css`
  with `@theme` (colors `rack`, `label`, `panel`, `amber`, `teal`; fonts `display`, `sans`, `mono`).
- **No shadcn/ui.** The brief explicitly rejects the identical-rounded-card kit; every component
  here is a bespoke rack/patch-panel primitive. Adding shadcn would fight the design system.
  (User said "if needed" — it isn't; custom components are simpler and more faithful.)
- **Fonts:** `Space Grotesk` (display headlines), `Inter` (body), `JetBrains Mono`
  (tabular numerals / spec tags / part numbers) — loaded via Google Fonts in `index.html`,
  with system fallbacks.

## Anti-pattern self-check (brief Section 8) — baked into the plan
- No eyebrow labels, no `A · B · C` meta joins, no `WORD — fragment` labels, no numbered 01/02/03
  markers on the catalog lists, no mid-word bold/italic headline punches, no `→` arrows on buttons.
- No rounded-card grids, no soft drop shadows, no gradient washes.
- Amber `#E8A33D` used only for: status LEDs, primary CTAs (WhatsApp), active nav states,
  focus rings — never decorative fills. Teal `#3F6B5C` only for secondary buttons/dividers.
- Motion: exactly one hero entrance (headline + photo settle, amber dot pulses once) + row hover
  reveals on rack lists. No scroll-triggered fade-ups. `prefers-reduced-motion` disables all of it.
- Keyboard focus visible in amber (`focus-visible:outline`).

## Project structure
```
um-pro/
├── index.html                     # fonts, meta, #root
├── vite.config.js                 # @vitejs/plugin-react + @tailwindcss/vite
├── src/
│   ├── main.jsx                   # router setup
│   ├── index.css                  # @theme tokens, base styles, keyframes, reduced-motion
│   ├── lib/site.js                # SITE config: whatsapp/phone/address placeholders (single edit point)
│   ├── data/content.js            # all real content: services, supplies, leadership, stats, objectives
│   ├── components/
│   │   ├── Nav.jsx                # thin fixed nav, logo left, 4 links, amber WhatsApp button
│   │   ├── Footer.jsx             # dense functional footer
│   │   ├── Hero.jsx               # home hero: headline block + equipment visual, one-shot pulse dot
│   │   ├── RackElevation.jsx      # core component: labelled rack-unit rows (repair/supply lists)
│   │   ├── StatsStrip.jsx         # large tabular numerals
│   │   ├── LeadershipBadge.jsx    # ID-badge/lanyard-style card (thin rules, no rounded shadow card)
│   │   ├── LogoRail.jsx           # client logos on a rack-rail line, grayscale until hover
│   │   ├── CTABand.jsx            # full-width amber-accented band, WhatsApp primary
│   │   ├── WhatsAppButton.jsx     # reusable amber CTA (nav, inline, footer)
│   │   └── QuoteForm.jsx          # contact form: company, equipment/segment, message
│   └── pages/
│       ├── Home.jsx               # hero, logo rail, vision/mission, 2 rack-elevation previews, stats, leadership, CTA
│       ├── About.jsx              # objectives (verbatim 3 bullets), Our Supplies rack elevation, full leadership bios
│       ├── Services.jsx           # Local Repair rack list, Get In Touch CTA, Supply rack list, Get In Touch CTA, gallery
│       └── Contact.jsx            # WhatsApp/phone direct + QuoteForm
└── public/images/                 # equipment visuals (see Imagery below)
```

## Imagery (important constraint)
No real client photos are available in this workspace, and the brief forbids generic stock
("smiling businesspeople"). Plan:
- Build the hero "equipment photograph" slot as a **self-contained SVG rack-elevation illustration**
  (rectifier modules, patch panel, status LEDs — drawn in the 5-token palette) saved at
  `public/images/hero-rack.svg`, styled warm/desaturated. A clearly marked `<img src>` slot in
  `Hero.jsx` makes swapping in a real photo a one-line change.
- Services gallery: 4–6 small SVG equipment plates (OTDR, rectifier, fiber patch panel, ATS panel)
  as placeholders with the same swap-in path.
- No external image URLs — site must work fully offline.

## Content (all from the brief, real — no filler)
- **Home:** hero headline on decade-plus repair/maintenance/supply of new & refurbished telecom
  gear for GSM/PSTN operators; trust bar incl. Nokia; Vision/Mission (leading, ethically-run
  telecom services provider in Pakistan); leadership badges: CEO Mr. Asif (SKS → Global One →
  Green Base Solutions → founder), COO/CTO Col (Retd) Muhammad Afzal Ahsan SI(M) (Pak Army
  PASCOMS, safe-city, USF Gilgit-Baltistan); CTA band → WhatsApp + Get a Quote.
- **About:** objectives verbatim (serve/manage network ops within operator budget; match OEM QoS;
  repair & supply excellence commitment); Our Supplies rack list: Delta ESR 48/40, Huawei R4850G2,
  Eltek 48/3000, optic modems, SolarMax & Inverex inverters, ATS panel, OTDR 1310, DC aircon,
  optical power meter, Emerson R48 2900U, ZXD 2400, Nera ODU/IDU, SPDs; full bios.
- **Services:** Local Repair rack list (rectifiers, microwave links, switching modules, RF
  repeaters, CTC modem, OTDR, splice machines, BTS fan trays/modules, Juniper routers, Cisco
  switching, ONT repair, TV box repair, UPS ≤30kVA/AVRs/ATS, environment modules, ZTE power/
  environment supervisory) + WhatsApp CTA; Supply rack list (SFPs, SPDs, OTDR, patch cords,
  optical modems, hand tools, fiber cable, rectifier modules/racks, ATS, splice consumables, duct
  rod, DC aircon, gensets, CCTV, networking cable, optical power monitors, DCDB/ACDB, multimeters/
  clamp meters, ODF 48/96/144) + WhatsApp CTA; gallery.
- **Contact:** WhatsApp + phone direct, short quote form (company name, equipment/segment, message).
- Contact details (WhatsApp number, phone, address) are **placeholders** centralized in
  `src/lib/site.js` — flagged in the final summary so the client replaces them in one file.

## Design tokens (Tailwind v4 @theme)
- `rack: #0E1613` (bg), `label: #F4F2EA` (text), `panel: #161F1B` (surfaces),
  `amber: #E8A33D`, `teal: #3F6B5C`. No pure black/white anywhere.
- Type scale: display via Space Grotesk (bold moments), body Inter max-w-[80ch], mono for all
  numerals/specs (`font-variant-numeric: tabular-nums`).

## Key components behavior
- **Nav:** fixed, thin, `border-b` hairline on panel; logo left; links: Home/About/Services/Contact;
  persistent amber WhatsApp button right; mobile: links collapse into a minimal row (no hamburger).
- **RackElevation rows:** `panel` background row, left item name, right thin amber/teal LED bar +
  spec tag revealed on hover/focus (opacity transition only). Rows separated by hairlines, not
  cards. Mobile: stack name over indicator.
- **Hero:** left-aligned headline block; SVG equipment visual bleeding right; amber status dot
  pulses exactly once via a single-run CSS keyframe (animation-iteration-count: 1), disabled under
  `prefers-reduced-motion`. Headline/photo settle with one subtle translate/fade on load only.
- **StatsStrip:** `12+` years, segments covered, sectors served, client count — big JetBrains Mono
  tabular numerals, hairline dividers, wraps 2×2 on mobile.
- **LeadershipBadge:** hairline-bordered panel, portrait placeholder (initials monogram in SVG —
  no fake faces), name, credential line, 2-line bio excerpt; thin top rule evoking a lanyard slot.
- **LogoRail:** horizontal hairline "rack rail" with Nokia + operator names as grayscale text
  wordmarks (no fake logo files), colorizing on hover.
- **CTABand:** full-width panel band with amber left border / accent, "Message on WhatsApp"
  primary + "Get a Quote" secondary (teal outline).
- **Footer:** address / phone / WhatsApp / quick links in dense columns, hairline top border.

## Accessibility & responsiveness
- WCAG AA: off-white on charcoal passes; amber used for text sparingly (large/bold CTA text only),
  decoration otherwise. Visible amber `focus-visible` rings. `prefers-reduced-motion` kills the
  pulse and entrance. Rows are real `<a>`/`<li>` structures reachable by keyboard; spec tags also
  reveal on `:focus-within`.

## Build & verify steps
1. `npm create vite@latest . -- --template react` (in `/home/shumail/um-pro`), install
   `react-router-dom`, `tailwindcss @tailwindcss/vite`.
2. Write tokens/base CSS, `site.js`, `content.js`.
3. Build components, then the 4 pages.
4. Create SVG imagery in `public/images/`.
5. `npm run build` must pass clean; `npm run dev` smoke-tested (curl each route's HTML shell).
6. Self-check against brief Section 8 list before finishing; report placeholder contact details
   the client must replace.

## Out of scope
Backend/form submission (form is static — `mailto:`/WhatsApp prefill or plain front-end only),
real client photography, logo files, deployment.
